# simp_note
Online Note Taking App
